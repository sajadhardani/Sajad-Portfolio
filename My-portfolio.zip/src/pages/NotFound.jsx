
export const NotFound = () =>{
    return(
        <div><h1>not found 404</h1></div>
    )
};